<!-- de inhoud van dit bestand wordt onderaan elke pagina geplaatst -->
<section class="text-left d-flex justify-content-between p-4 text-white footer-pos" style="background-color: #676EFF">
        <div class="container">
            <div class="row">
                <div class="align-middle col-md-6">
                    <div class="footer-socials-heading">
                        <h5>Gegevens van ons bedrijf.</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

            
<div class="col-md-3 col-lg-2 mx-auto mb-1 footer-text-pos footer-pos">
                    <br>
                    <h6>Nerdygadgets</h6>
                    <p class="footer-link">
                        Campus 2<br>
                        8017 CA Zwolle<br>
                        BTW: NL 1234.05.678.B01<br>
                        Tel: 088 469 9911<br>
                    </p>
                </div>


<div class="container pb-4" style="background-color: rgb(35, 35, 47) footer-pos">
        <div class="row">
            <div class="col-md-6 footer-pos">
                <div class="text-left p-3" style="background-color: rgb(35, 35, 47) footer-pos">
                    © 2022
                    <a class="text-white" href="/nerdygadgets-main/">Nerdygadgets</a>
                </div>
            </div>
            <div class="col-md-6 footer-pos">
                <div class="d-flex justify-content-end">
                    <div class="text-left p-3" style="background-color: rgb(35, 35, 47) footer-pos">
                        <a class="text-white" href="/nerdygadgets-main/">Algemene voorwaarden</a>
                    </div>
                    <div class="text-left p-3" style="background-color: rgb(35, 35, 47) footer-pos">
                        <a class="text-white" href="/nerdygadgets-main/">Privacy beleid</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
